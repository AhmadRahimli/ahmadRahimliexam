package question2.managers

import question2.IStoreData

class PayPalManager:IStoreData {
    override fun pay() {

    }
}