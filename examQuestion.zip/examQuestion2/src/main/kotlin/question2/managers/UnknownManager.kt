package question2.managers

import question2.IStoreData

class UnknownManager:IStoreData {
    override fun pay() {

    }
}