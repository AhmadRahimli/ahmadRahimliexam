package question2.managers

import question2.IStoreData

class CreditCardmanager:IStoreData {
    override fun pay() {

    }
}