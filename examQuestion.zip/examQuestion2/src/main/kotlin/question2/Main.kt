package question2

import question2.managers.CreditCardmanager
import question2.managers.PayPalManager
import question2.managers.UnknownManager
import question2.service.StoreService

fun main(){
    val storeservice= StoreService()

    storeservice.payMethod(CreditCardmanager())
    storeservice.payMethod(PayPalManager())
    storeservice.payMethod(UnknownManager())
}