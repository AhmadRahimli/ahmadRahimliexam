package question2.service

import question2.IStoreData

class StoreService {
    fun payMethod(IStoreData:IStoreData){
           IStoreData.pay()
    }
}