package question2

interface IStoreData {
    fun pay()
}

