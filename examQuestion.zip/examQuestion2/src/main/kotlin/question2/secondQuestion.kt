package question2

class secondQuestion {
//    class PaymentProcessor {
//        public:
//        void processPayment(Payment* payment) {
//            if (payment->type() == "CreditCard") {
                // Process credit card payment.
//            } else if (payment->type() == "PayPal") {
     //            Process PayPal payment.
//            } else {
  //               Unknown payment type.
//            }
//        }
//    };

}