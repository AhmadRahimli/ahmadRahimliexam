package question9

fun main(){
    println("Enter your number")
   var a= readLine()!!.toInt()

    if(a%400==0){
        println("$a is leap year")
    }
    else{
        println("$a is not leap year")
    }
}