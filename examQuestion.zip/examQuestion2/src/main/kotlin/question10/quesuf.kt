package question10


fun main(){
    println("enter value of a,b,c ")
    var a= readLine()!!.toDouble()
    var b= readLine()!!.toDouble()
    var c= readLine()!!.toDouble()
    var determine=(b*b)-(4*a*c)
    if (a.toInt() ==0 ){
        println("a can not be zero")
    }
    else{
        println("determine="+determine)
    }
    if (determine>0){
        println("it has two roots")
    }
    else if (determine.toInt() ==0){
        println("it has one root")
    }
    else if (determine<0){
        println("there is no reaal root")
    }

}