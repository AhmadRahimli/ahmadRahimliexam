package question1

class question {
//    class Student {
//        var name: String
//        var age: Int
//        var marks: Int
//
//        fun calculateGrades() : String {
       //      Code to calculate grades
//        }
//
//        fun printStudentInformation() {
       //      Code to print student information to the console
//        }
//    }

}