package question1.data

data class Order(
    var name: String,
    var age: Int,
    var marks: Int

)
