package question1.factory

import question1.data.Order
import question1.managers.OrderCalculateGrades
import question1.managers.OrderPrintStudentInformation

class OrderFacade (
    private val calculateGrades: OrderCalculateGrades,
    private val studentInformation: OrderPrintStudentInformation,

    ){

        fun sendNotification(order: Order) {
            // sends notification about order updates to the user.
            calculateGrades.grades(order)
        }

        fun generateInvoice(order: Order) {
            // generates invoice
            studentInformation.studentInformation(order)
        }
}
