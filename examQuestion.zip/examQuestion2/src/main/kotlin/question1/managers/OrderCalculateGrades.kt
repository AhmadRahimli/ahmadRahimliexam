package question1.managers

import question1.data.Order

class OrderCalculateGrades {
    fun grades(order: Order) {
        // calculate grades
    }
}