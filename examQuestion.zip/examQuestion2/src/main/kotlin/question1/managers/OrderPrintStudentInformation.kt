package question1.managers

import question1.data.Order

class OrderPrintStudentInformation {
    fun studentInformation(order: Order) {
        // calculate grades
    }
}